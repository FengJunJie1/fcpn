function [record_m,record_sigma,record_w,record_ym] = mamdanifis(inputs,outputs,numMFs,train_m,train_sigma,rules,rulesize,epoch,rate,a,b,kk,andMethod,input_test,output_test,input_all,output_all,R1,R2)
    [numVars,N]=size(inputs);
    m=train_m;
    sigma=train_sigma;
    min_value=min(outputs);
    max_value=max(outputs);
    w=unifrnd(min_value,max_value,1,rulesize);
    record_min=99999;
    ym=ones(1,N);
    for i=1:rulesize-1
        for j=i+1:rulesize
            if rules(i,numVars+1)==rules(j,numVars+1)
                w(1,j)=w(1,i);
            end
        end
    end
    for ii=1:epoch
        for iii=1:N
            sum_delta_m=zeros(numVars,numMFs);
            sum_delta_sigma=zeros(numVars,numMFs);
            sum_delta_w=zeros(1,rulesize);

            net1=inputs(:,iii);
            y1=net1;

            net2=ones(numVars,numMFs);
            for i=1:numVars
                for j=1:numMFs
                    net2(i,j)=-(y1(i)-m(i,j))^2/(2*sigma(i,j)^2);
                end
            end
            y2=exp(net2);

            if strcmp('Minimum',andMethod)
                for k=1:rulesize
                    min_val=99999;
                    for i=1:numVars
                        if min_val>y2(i,rules(k,i))
                            recorderx(k)=i;
                            recordery(k)=rules(k,i);
                            result(k)=y2(i,rules(k,i));
                            min_val=result(k);
                        end
                    end
                end
            else
                for k=1:rulesize
                    result(k)=1;
                    for i=1:numVars
                        result(k)=result(k)*y2(i,rules(k,i));
                    end
                end
            end
            net3=result;
            y3=net3;

            y4=ones(1,rulesize);
            net4_sum=sum(y3);
            for k=1:rulesize
                y4(1,k)=y3(k)/net4_sum;
                if isnan(y4(1,k))
                    y4(1,k)=0;
                end
            end

            y5=sum(w.*y4);

            ave_y4=y4;
            for i=1:rulesize
                count=0;
                recorder=zeros(1,rulesize);
                for j=1:rulesize
                    if rules(i,numVars+1)==rules(j,numVars+1)
                        count=count+1;
                        recorder(1,j)=1;
                    end
                end
                sum_y4=0;
                for j=1:rulesize
                    if recorder(1,j)==1
                        sum_y4=sum_y4+y4(j);
                    end
                end
                ave_y4(1,i)=sum_y4/count;
            end
            delta_w=rate*(outputs(1,iii)-y5)*ave_y4;
            sum_delta_w=sum_delta_w+delta_w;

            delta=zeros(numVars,numMFs);
            for k=1:rulesize
                sum_delta=zeros(numVars,numMFs);
                s=zeros(numVars,numMFs);
                if strcmp('Minimum',andMethod)
                    s(recorderx(k),recordery(k))=1;
                else
                    for i=1:numVars
                        for j=1:numMFs
                            if rules(k,i)==j
                                s(i,j)=result(k)/y2(i,j);
                                if isnan(s(i,j))
                                    s(i,j)=0;
                                end
                            end
                        end
                    end
                end
                sum_exp_a=sum(result);
                sum_a=sum(result);
                sum_exp_a=sum_exp_a-result(1,k);
                fraccc=sum_exp_a/(sum_a^2);
                for i=1:numVars
                    for j=1:numMFs
                        sum_delta(i,j)=-(outputs(1,iii)-y5)*w(1,k)*fraccc*s(i,j)*exp(-(y1(i)-m(i,j))^2/(2*sigma(i,j)^2));
                    end
                end
                delta=delta+sum_delta;
            end

            for i=1:numVars
                for j=1:numMFs
                    delta_m(i,j)=-rate*delta(i,j)*(y1(i)-m(i,j))/(sigma(i,j)^2);
                end
            end
            sum_delta_m=sum_delta_m+delta_m;

            for i=1:numVars
                for j=1:numMFs
                    delta_sigma(i,j)=-rate*delta(i,j)*(y1(i)-m(i,j))^2/(sigma(i,j)^3);
                end
            end
            sum_delta_sigma=sum_delta_sigma+delta_sigma;

            e(iii)=(outputs(1,iii)-y5)^2/2;
            ym(1,iii)=y5;
            m=m+sum_delta_m;
            sigma=sigma+sum_delta_sigma;
            w=w+sum_delta_w;
            %%{
            if iii>1
                if e(iii)/e(iii-1)<1
                    rate=rate*a;
                elseif e(iii)/e(iii-1)>=kk
                    rate=rate*b;
                end
            end
            %}
        end
        E(ii)=sum(abs(e));
        if ii==1
            record_min=E(ii);
            record_m=m;
            record_sigma=sigma;
            record_w=w;
            record_ym=ym;
        elseif record_min>E(ii)
            record_min=E(ii);
            record_m=m;
            record_sigma=sigma;
            record_w=w;
            record_ym=ym;
        end
    end
    %figure(1);
    subplot(311);
    plot(1:epoch,E,'r','LineWidth',1.5);
    xlabel('Epoch');
    ylabel('Error');
    %figure(2);
    subplot(312);
    plot(R2/100,record_ym,'.r','LineWidth',1.5);
    hold on
    subplot(312);
    plot(R2/100,outputs,'.k','LineWidth',1.5);
    legend('Predict(Train)','Actual(Train)');
    xlabel('Time');
    ylabel('Concentration change');
    [numVars,N]=size(input_test);
    for iii=1:N
        net1=input_test(:,iii);
        y1=net1;
        net2=ones(numVars,numMFs);
        for i=1:numVars
            for j=1:numMFs
                net2(i,j)=-(y1(i)-record_m(i,j))^2/(2*record_sigma(i,j)^2);
            end
        end
        y2=exp(net2);
        if strcmp('Minimum',andMethod)
         	for k=1:rulesize
                min_val=99999;
              	for i=1:numVars
                    if min_val>y2(i,rules(k,i))
                        recorderx(k)=i;
                        recordery(k)=rules(k,i);
                        result(k)=y2(i,rules(k,i));
                        min_val=result(k);
                    end
                end
        	end
        else
        	for k=1:rulesize
                result(k)=1;
             	for i=1:numVars
                    result(k)=result(k)*y2(i,rules(k,i));
                end
            end
        end
       	net3=result;
       	y3=net3;
        y4=ones(1,rulesize);
       	net4_sum=sum(y3);
      	for k=1:rulesize
          	y4(1,k)=y3(k)/net4_sum;
        	if isnan(y4(1,k))
            	y4(1,k)=0;
            end
        end
        y5(1,iii)=sum(record_w.*y4);
    end
    %figure(3);
    subplot(313);
    plot(R1/100,y5,'.r','LineWidth',1.5);
    hold on
    subplot(313);
    plot(R1/100,output_test,'.k','LineWidth',1.5);
    legend('Predict(Test)','Actual(Test)');
    xlabel('Time');
    ylabel('Concentration change');
    
    
    [numVars,N]=size(input_all);
    for iii=1:N
        net1=input_all(:,iii);
        y1=net1;
        net2=ones(numVars,numMFs);
        for i=1:numVars
            for j=1:numMFs
                net2(i,j)=-(y1(i)-record_m(i,j))^2/(2*record_sigma(i,j)^2);
            end
        end
        y2=exp(net2);
        if strcmp('Minimum',andMethod)
         	for k=1:rulesize
                min_val=99999;
              	for i=1:numVars
                    if min_val>y2(i,rules(k,i))
                        recorderx(k)=i;
                        recordery(k)=rules(k,i);
                        result(k)=y2(i,rules(k,i));
                        min_val=result(k);
                    end
                end
        	end
        else
        	for k=1:rulesize
                result(k)=1;
             	for i=1:numVars
                    result(k)=result(k)*y2(i,rules(k,i));
                end
            end
        end
       	net3=result;
       	y3=net3;
        y4=ones(1,rulesize);
       	net4_sum=sum(y3);
      	for k=1:rulesize
          	y4(1,k)=y3(k)/net4_sum;
        	if isnan(y4(1,k))
            	y4(1,k)=0;
            end
        end
        y5(1,iii)=sum(record_w.*y4);
    end
    %{
    figure(4);
    plot((1:N)/100,y5,'r','LineWidth',1.5);
    hold on
    plot((1:N)/100,output_all,'--k','LineWidth',1.5);
    legend('Predict(All)','Actual(All)');
    xlabel('Time');
    ylabel('Concentration change');
    %}
end
